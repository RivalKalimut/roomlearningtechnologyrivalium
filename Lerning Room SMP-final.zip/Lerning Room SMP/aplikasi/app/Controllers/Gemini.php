<?php

namespace App\Controllers;

use App\Models\ChatAiModel;
use CodeIgniter\HTTP\ResponseInterface;

class Gemini extends BaseController
{
    public function index()
    {
        $role = session()->get('user_role') ?? 'siswa';
        return view('gemini/index', [
            'userRole' => $role,
        ]);
    }

    public function ask(): ResponseInterface
    {
        $prompt = $this->request->getPost('prompt');
        $context = $this->request->getPost('context');
        $mapel = $this->request->getPost('mapel') ?? '';
        $apiKey = env('gemini.api_key');
        $userRole = session()->get('user_role') ?? 'siswa';
        $isGuru = ($userRole === 'guru');

        if (empty($prompt)) {
            return $this->response->setJSON([
                'success'    => false,
                'message'    => 'Pertanyaan tidak boleh kosong.',
                'csrf_token' => csrf_hash(),
            ]);
        }

        // Jika API Key belum diisi atau masih default placeholder
        if (empty($apiKey) || $apiKey === 'YOUR_GEMINI_API_KEY') {
            if ($isGuru) {
                $demoResponse = "Halo Bapak/Ibu Guru! Berikut adalah **Referensi Rancangan Pembelajaran & Modul Ajar (Kurikulum Merdeka)** 📋:\n\n"
                    . "### 1. Informasi Umum & Capaian Pembelajaran\n"
                    . "- **Mata Pelajaran**: Matematika / IPA Terpadu Kelas VIII SMP\n"
                    . "- **Materi Pokok**: Penyelesaian Masalah & Statistika / Ekosistem\n"
                    . "- **Profil Pelajar Pancasila**: Bernalar Kritis, Mandiri, dan Gotong Royong\n\n"
                    . "### 2. Tujuan Pembelajaran Bermakna\n"
                    . "1. Siswa mampu menganalisis hubungan data menggunakan perhitungan rata-rata terpadu.\n"
                    . "2. Siswa mampu merumuskan kesimpulan logis dari studi kasus nyata di lingkungan sekitar.\n\n"
                    . "### 3. Alur Kegiatan Pembelajaran (Berdiferensiasi)\n"
                    . "- **Pendahuluan (10 Menit)**: *Apersepsi* berbasis masalah kontekstual & pertanyaan pemantik untuk memancing keaktifan siswa.\n"
                    . "- **Kegiatan Inti (60 Menit)**: Kerja kelompok kooperatif dengan lembar aktivitas (LKPD) bertingkat (dasar, sedang, pengayaan).\n"
                    . "- **Penutup & Refleksi (10 Menit)**: Siswa menyampaikan kesimpulan dan guru memberikan umpan balik penguatan konsep.\n\n"
                    . "### 4. Contoh Instrumen Asesmen HOTS & Rubrik\n"
                    . "| Kriteria Penilaian | Skor 4 (Sangat Baik) | Skor 3 (Baik) | Skor 2 (Cukup) |\n"
                    . "| :--- | :--- | :--- | :--- |\n"
                    . "| **Pemahaman Konsep** | Mampu menjelaskan rumus & logika secara sempurna | Menjelaskan konsep dengan benar namun ada 1 kekeliruan | Membutuhkan bimbingan rumus dasar |\n"
                    . "| **Kreativitas Solusi** | Menerapkan langkah alternatif yang efisien | Mengikuti langkah standar dengan tepat | Masih belum runtut |\n\n"
                    . "> 💡 **Tips Guru**: Gunakan media visual atau asesmen diagnostik di awal pembelajaran untuk memetakan kesiapan belajar siswa.";
            } else {
                $demoResponse = "Halo! Mari kita bahas soal ini bersama-sama menggunakan konsep **rata-rata gabungan** 📊.\n\n"
                    . "### 1. Konsep & Rumus Dasar\n"
                    . "Rumus rata-rata gabungan dari dua kelas adalah:\n"
                    . "$$\\bar{x}_{\\text{gab}} = \\frac{(n_1 \\times \\bar{x}_1) + (n_2 \\times \\bar{x}_2)}{n_1 + n_2}$$\n\n"
                    . "### 2. Langkah-Langkah Penyelesaian\n"
                    . "- **Langkah 1**: Hitung total nilai kelas pertama:\n"
                    . "$$\\text{Total Nilai 1} = 41 \\times 6,80 = 278,8$$\n"
                    . "- **Langkah 2**: Hitung total nilai gabungan kedua kelas (total siswa = $41 + 39 = 80$ siswa):\n"
                    . "$$\\text{Total Nilai Gabungan} = 80 \\times 6,28 = 502,4$$\n"
                    . "- **Langkah 3**: Hitung total nilai kelas kedua:\n"
                    . "$$\\text{Total Nilai 2} = 502,4 - 278,8 = 223,6$$\n"
                    . "- **Langkah 4**: Hitung nilai rata-rata kelas kedua:\n"
                    . "$$\\bar{x}_2 = \\frac{223,6}{39} \\approx \\mathbf{5,73}$$\n\n"
                    . "### 3. Kesimpulan & Jawaban Akhir\n"
                    . "Jadi, nilai rata-rata kelas kedua yang terdiri dari 39 siswa adalah **5,73**.";
            }

            // Simpan riwayat chat demo
            $chatModel = new ChatAiModel();
            $chatModel->save([
                'user_id'    => session()->get('user_id'),
                'mapel'      => $mapel,
                'prompt'     => $prompt,
                'response'   => $demoResponse,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            return $this->response->setJSON([
                'success'    => true,
                'text'       => $demoResponse,
                'is_demo'    => true,
                'csrf_token' => csrf_hash(),
            ]);
        }

        // Tentukan instruksi sistem berdasarkan peran pengguna
        if ($isGuru) {
            $systemInstruction = "Kamu adalah **Model Gemini AI Asisten Referensi Mengajar Guru (Teaching Assistant)** untuk guru SMP di platform Room Learning SMP.\n\n"
                . "PEDOMAN REFERENSI UNTUK MENGAJAR:\n"
                . "1. Berikan referensi pedagogis yang lengkap, terstruktur, inovatif, dan selaras dengan prinsip Kurikulum Merdeka SMP.\n"
                . "2. Setiap kali guru meminta ide materi, rancangan pembelajaran, atau evaluasi, susun respons dengan struktur:\n"
                . "   - **Identitas & Capaian Pembelajaran (CP) / Tujuan Pembelajaran (TP)** yang spesifik.\n"
                . "   - **Metode & Strategi Mengajar Aktif**: (Problem-Based Learning, Project-Based Learning, Pembelajaran Berdiferensiasi, dsb.).\n"
                . "   - **Skenario Aktivitas Pembelajaran**: Kegiatan Awal/Apersepsi menarik, Kegiatan Inti eksploratif, dan Kegiatan Penutup/Refleksi.\n"
                . "   - **Bank Soal & Asesmen (HOTS)**: Soal berbasis konteks nyata beserta kunci jawaban & indikator capaian.\n"
                . "   - **Rubrik Penilaian Objektif**: Dalam bentuk tabel kriteria dan penskoran yang mudah diaplikasikan.\n"
                . "   - **Tips Manajemen Kelas & Ice Breaking Edukatif** yang relevan.\n"
                . "3. Gunakan bahasa yang profesional, santun, inspiratif, dan mudah diterapkan langsung di dalam kelas.";
        } else {
            $systemInstruction = "Kamu adalah **Model Gemini AI Pembelajaran Terpadu (Tutor Virtual Cerdas)** untuk seluruh mata pelajaran jenjang SMP (usia 12–15 tahun) di platform Room Learning SMP.\n\n"
                . "CAKUPAN MATA PELAJARAN:\n"
                . "Kamu menguasai seluruh kurikulum SMP: **Matematika, IPA (Fisika/Biologi/Kimia), Bahasa Indonesia, Bahasa Inggris, IPS (Sejarah/Geografi/Sosiologi/Ekonomi), Informatika, Pendidikan Pancasila (PPKn), Seni Budaya, PJOK, dan Prakarya**.\n\n"
                . "ATURAN MUTLAK & PEDOMAN TAHAPAN PENJELASAN:\n"
                . "Jika pertanyaan atau topik melibatkan RUMUS, HITUNGAN, SOAL, atau PEMBAHASAN MATERI BERHITUNG (seperti Matematika, IPA Fisika, Aritmatika, dsb.), kamu WAJIB MENAMPILKAN RUMUS SECARA EKSPLISIT DENGAN TAHAPAN RUNTUT SEBAGAI BERIKUT:\n\n"
                . "### 1. Konsep Dasar & Rumus Utama\n"
                . "Tampilkan rumus matematika/fisika yang digunakan secara jelas menggunakan format KaTeX / LaTeX standar (gunakan `$$...$$` untuk rumus pada baris tersendiri atau `$...$` untuk inline). Jelaskan arti dari setiap simbol atau variabel dalam rumus tersebut.\n\n"
                . "### 2. Informasi yang Diketahui & Ditanya\n"
                . "Tuliskan rincian apa saja yang diketahui dari soal (beserta satuannya) dan apa yang dicari/ditanyakan.\n\n"
                . "### 3. Langkah-Langkah Penyelesaian & Substitusi Rumus (Step-by-Step)\n"
                . "Uraikan penyelesaian secara bertahap (Langkah 1, Langkah 2, dst.). Tuliskan proses memasukkan (substitusi) angka ke dalam rumus hingga didapatkan hasil perhitungannya. Siswa harus melihat secara gamblang dari mana asal setiap angka.\n\n"
                . "### 4. Kesimpulan & Jawaban Akhir\n"
                . "Tuliskan jawaban akhir dengan tegas dan **tebalkan nilai jawaban akhirnya** beserta satuan yang benar.\n\n"
                . "UNTUK PERTANYAAN TEORI, ANALISIS, DAN BAHASA:\n"
                . "- Uraikan materi secara terstruktur (Pengertian, Poin-poin penting, Contoh nyata, dan Kesimpulan).\n"
                . "- Gunakan bahasa yang komunikatif, ramah, membangkitkan rasa ingin tahu, dan mudah dipahami oleh siswa SMP.";
        }

        if (!empty($mapel)) {
            $systemInstruction .= "\n\nMata Pelajaran yang ditanyakan siswa: " . $mapel . " SMP. Sesuaikan penjelasan konsep dan contoh dengan materi kurikulum " . $mapel . " SMP.";
        }

        if (!empty($context)) {
            $systemInstruction .= "\n\nKonteks materi yang sedang dipelajari siswa:\n" . $context;
        }

        // Siapkan riwayat obrolan (multi-turn history)
        $historyRaw = $this->request->getPost('history');
        $contents = [];
        if (!empty($historyRaw)) {
            $decodedHistory = json_decode($historyRaw, true);
            if (is_array($decodedHistory)) {
                foreach ($decodedHistory as $h) {
                    if (isset($h['role'], $h['parts']) && in_array($h['role'], ['user', 'model'])) {
                        $contents[] = [
                            'role'  => $h['role'],
                            'parts' => [['text' => (string) ($h['parts'][0]['text'] ?? '')]],
                        ];
                    }
                }
            }
        }

        // Tambahkan prompt terkini
        $contents[] = [
            'role'  => 'user',
            'parts' => [['text' => $prompt]],
        ];

        $payload = [
            'system_instruction' => [
                'parts' => [['text' => $systemInstruction]],
            ],
            'contents' => $contents,
        ];

        $models = ['gemini-3.5-flash-lite', 'gemini-3.5-flash', 'gemini-3.6-flash', 'gemini-flash-lite-latest'];
        $client = service('curlrequest');
        $successText = null;
        $lastError = 'Tidak ada respons dari AI.';

        foreach ($models as $modelName) {
            try {
                $response = $client->request('POST', "https://generativelanguage.googleapis.com/v1beta/models/{$modelName}:generateContent?key=" . $apiKey, [
                    'headers'     => ['Content-Type' => 'application/json'],
                    'json'        => $payload,
                    'timeout'     => 45,
                    'http_errors' => false,
                    'verify'      => false,
                ]);

                $body = json_decode((string) $response->getBody(), true);

                if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
                    $successText = $body['candidates'][0]['content']['parts'][0]['text'];
                    break;
                }

                if (isset($body['error']['message'])) {
                    $lastError = $body['error']['message'];
                }
            } catch (\Exception $e) {
                $lastError = $e->getMessage();
            }
        }

        if ($successText !== null) {
            // Simpan riwayat chat
            $chatModel = new ChatAiModel();
            $chatModel->save([
                'user_id'    => session()->get('user_id'),
                'mapel'      => $mapel,
                'prompt'     => $prompt,
                'response'   => $successText,
                'created_at' => date('Y-m-d H:i:s'),
            ]);

            return $this->response->setJSON([
                'success'    => true,
                'text'       => $successText,
                'csrf_token' => csrf_hash(),
            ]);
        }

        return $this->response->setJSON([
            'success'    => false,
            'message'    => 'Google Gemini: ' . $lastError,
            'csrf_token' => csrf_hash(),
        ]);
    }
}

