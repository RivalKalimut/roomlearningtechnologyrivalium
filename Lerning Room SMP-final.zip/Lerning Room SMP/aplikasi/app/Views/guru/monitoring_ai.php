<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Monitoring AI Siswa - Room Learning SMP</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
  <style>
    body { font-family: 'Plus Jakarta Sans', sans-serif; }
    .custom-scroll::-webkit-scrollbar { width: 5px; height: 5px; }
    .custom-scroll::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 9999px; }
  </style>
</head>
<body class="bg-slate-50 text-slate-800 flex h-screen overflow-hidden">

  <!-- Sidebar Guru -->
  <aside class="w-64 bg-white border-r border-slate-200 flex flex-col justify-between shrink-0 p-4 z-10 shadow-sm">
    <div>
      <div class="p-3 mb-4 flex items-center gap-2">
        <div class="w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center font-bold text-sm shadow-sm">
          <i class="fa-solid fa-graduation-cap"></i>
        </div>
        <div>
          <h2 class="font-extrabold text-xs text-slate-800 leading-none">Room Learning</h2>
          <span class="text-[9px] font-bold text-blue-600">SMP</span>
        </div>
      </div>
      <nav class="space-y-1">
        <a href="<?= site_url('guru/dashboard') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold text-xs">
          <i class="fa-solid fa-house w-4"></i><span>Beranda</span>
        </a>
        <a href="<?= site_url('guru/kelas-siswa') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold text-xs">
          <i class="fa-solid fa-users-rectangle w-4"></i><span>Kelas & Siswa</span>
        </a>
        <a href="<?= site_url('guru/jadwal') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold text-xs">
          <i class="fa-regular fa-calendar-days w-4"></i><span>Jadwal Belajar</span>
        </a>
        <a href="<?= site_url('guru/materi') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold text-xs">
          <i class="fa-regular fa-book-open w-4"></i><span>Kelola Materi</span>
        </a>
        <a href="<?= site_url('guru/tugas') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold text-xs">
          <i class="fa-regular fa-clipboard w-4"></i><span>Kelola Tugas</span>
        </a>
        <a href="<?= site_url('guru/nilai') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold text-xs">
          <i class="fa-regular fa-award w-4"></i><span>Nilai</span>
        </a>
        <!-- Menu Aktif Monitoring AI -->
        <a href="<?= site_url('guru/monitoring-ai') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl bg-indigo-50 text-indigo-700 font-extrabold text-xs shadow-xs border border-indigo-100">
          <i class="fa-solid fa-chart-line w-4 text-indigo-600"></i><span>Monitoring AI Siswa</span>
        </a>
        <a href="<?= site_url('guru/profil') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold text-xs">
          <i class="fa-regular fa-user w-4"></i><span>Profil</span>
        </a>
        <a href="<?= site_url('gemini') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-600 hover:bg-slate-50 font-semibold text-xs">
          <i class="fa-solid fa-robot w-4"></i><span>Gemini AI (Tutor Guru)</span>
        </a>
      </nav>
    </div>
    <a href="<?= site_url('logout') ?>" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-red-500 hover:bg-red-50 font-bold text-xs">
      <i class="fa-solid fa-right-from-bracket w-4"></i><span>Keluar</span>
    </a>
  </aside>

  <!-- Main Content -->
  <main class="flex-1 overflow-y-auto p-6 md:p-8 custom-scroll">
    
    <!-- Header Page -->
    <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
      <div>
        <div class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-[11px] font-extrabold border border-indigo-200 mb-2">
          <i class="fa-solid fa-brain text-indigo-600"></i>
          <span>Insight & Evaluasi Pembelajaran Berbantuan AI</span>
        </div>
        <h1 class="text-2xl font-black text-slate-900 tracking-tight">Monitoring Chat AI Siswa</h1>
        <p class="text-xs text-slate-500 mt-1">
          Pantau riwayat pertanyaan siswa per individu untuk melihat konsep materi yang dirasa sulit sebagai bahan evaluasi guru di kelas.
        </p>
      </div>

      <div class="flex items-center gap-2">
        <span class="inline-flex items-center gap-1.5 text-xs bg-emerald-50 text-emerald-700 border border-emerald-200 px-3.5 py-1.5 rounded-xl font-bold shadow-xs">
          <i class="fa-solid fa-book-bookmark text-emerald-600"></i>
          Mapel Anda: <span class="underline font-black"><?= !empty($mapel) ? esc($mapel) : 'Semua Mapel' ?></span>
        </span>
      </div>
    </div>

    <!-- 3 Info Metric Cards: Evaluasi Konsep Materi -->
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
      
      <div class="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div class="flex items-center justify-between text-slate-400 mb-2">
          <span class="text-[11px] font-extrabold uppercase tracking-wider text-slate-500">Total Obrolan Siswa</span>
          <div class="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs">
            <i class="fa-solid fa-comments"></i>
          </div>
        </div>
        <h3 class="text-2xl font-black text-slate-900"><?= esc($totalChat) ?></h3>
        <p class="text-[11px] text-slate-400 mt-0.5">
          <?= !empty($selectedStudent) ? 'Pertanyaan khusus dari ' . esc($selectedStudent['nama']) : 'Total pertanyaan siswa pada mapel ' . esc($mapel ?: 'umum') ?>
        </p>
      </div>

      <div class="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div class="flex items-center justify-between text-slate-400 mb-2">
          <span class="text-[11px] font-extrabold uppercase tracking-wider text-slate-500">Siswa Aktif Bertanya</span>
          <div class="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xs">
            <i class="fa-solid fa-users"></i>
          </div>
        </div>
        <h3 class="text-2xl font-black text-slate-900"><?= count($studentList) ?> <span class="text-xs font-semibold text-slate-400">Siswa</span></h3>
        <p class="text-[11px] text-slate-400 mt-0.5">Klik salah satu nama siswa di bawah untuk melihat detailnya</p>
      </div>

      <!-- Kartu Evaluasi Konsep Materi yang Sering Ditanyakan (Bukan kata umum soal) -->
      <div class="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div class="flex items-center justify-between text-slate-400 mb-2">
          <span class="text-[11px] font-extrabold uppercase tracking-wider text-slate-500">Konsep Evaluasi Guru</span>
          <div class="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xs">
            <i class="fa-solid fa-lightbulb"></i>
          </div>
        </div>
        <div class="flex flex-wrap gap-1.5 mt-1">
          <?php if (!empty($topKeywords)): ?>
            <?php foreach (array_slice($topKeywords, 0, 5) as $word => $count): ?>
              <span class="px-2.5 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-lg text-xs font-bold inline-flex items-center gap-1">
                <i class="fa-solid fa-magnifying-glass-chart text-[9px] text-amber-600"></i>
                <?= esc(ucfirst($word)) ?> <span class="text-[10px] text-amber-600 font-normal">(<?= $count ?>x)</span>
              </span>
            <?php endforeach; ?>
          <?php else: ?>
            <span class="text-xs text-slate-400 italic">Belum cukup data konsep materi.</span>
          <?php endif; ?>
        </div>
      </div>

    </div>

    <!-- PANEL FILTER KONTROL TERPADU: PILIH KELAS & PILIH SISWA -->
    <div class="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs mb-6">
      <div class="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xs font-bold">
            <i class="fa-solid fa-sliders"></i>
          </div>
          <div>
            <h3 class="text-xs font-black uppercase tracking-wider text-slate-800">Filter Analisis: Pilih Kelas & Siswa</h3>
            <p class="text-[11px] text-slate-400">Pilih rombongan belajar dan tentukan siswa untuk membaca rekam jejak belajarnya</p>
          </div>
        </div>

        <?php if (!empty($filterKelas) || !empty($filterSiswa) || !empty($search)): ?>
          <a href="<?= site_url('guru/monitoring-ai') ?>" class="text-[11px] font-extrabold text-rose-600 hover:text-rose-700 inline-flex items-center gap-1.5 bg-rose-50 px-3 py-1.5 rounded-xl border border-rose-100 transition">
            <i class="fa-solid fa-rotate-left"></i>
            <span>Reset Semua Filter</span>
          </a>
        <?php endif; ?>
      </div>

      <!-- Form Filter Interaktif -->
      <form action="<?= site_url('guru/monitoring-ai') ?>" method="GET" class="grid grid-cols-1 sm:grid-cols-12 gap-3.5">
        
        <!-- 1. Pilihan Kelas (Dropdown & Tombol) -->
        <div class="sm:col-span-4">
          <label class="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block mb-1.5">
            <i class="fa-solid fa-school text-indigo-500 mr-1"></i> 1. Pilih Kelas / Rombel:
          </label>
          <select name="kelas" onchange="this.form.submit()" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 cursor-pointer">
            <option value="">-- Semua Kelas --</option>
            <?php foreach (($combinedKelas ?? $kelasList) as $k): ?>
              <option value="<?= esc($k) ?>" <?= ($filterKelas === $k) ? 'selected' : '' ?>>
                Kelas <?= esc($k) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- 2. Pilihan Siswa di Kelas Tersebut -->
        <div class="sm:col-span-5">
          <label class="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block mb-1.5">
            <i class="fa-solid fa-user-graduate text-teal-600 mr-1"></i> 2. Pilih Siswa:
          </label>
          <select name="siswa_id" onchange="this.form.submit()" class="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 cursor-pointer">
            <option value="">-- Semua Siswa (<?= count($studentList) ?> Siswa) --</option>
            <?php foreach ($studentList as $s): ?>
              <option value="<?= $s['id'] ?>" <?= ($filterSiswa == $s['id']) ? 'selected' : '' ?>>
                <?= esc($s['nama']) ?> (Kelas <?= esc($s['kelas']) ?> • <?= $s['total_tanya'] ?>x Tanya)
              </option>
            <?php endforeach; ?>
          </select>
        </div>

        <!-- 3. Pencarian Kata Kunci / Topik -->
        <div class="sm:col-span-3">
          <label class="text-[11px] font-extrabold uppercase tracking-wider text-slate-500 block mb-1.5">
            <i class="fa-solid fa-magnifying-glass text-slate-400 mr-1"></i> 3. Cari Materi:
          </label>
          <div class="relative">
            <input type="text" name="q" value="<?= esc($search ?? '') ?>" placeholder="Ketik kata kunci..." class="w-full pl-3.5 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500">
            <button type="submit" class="absolute right-2 top-1/2 -translate-y-1/2 w-6 h-6 bg-indigo-600 text-white rounded-lg flex items-center justify-center text-[10px] hover:bg-indigo-700 transition">
              <i class="fa-solid fa-arrow-right"></i>
            </button>
          </div>
        </div>

      </form>
    </div>

    <!-- Riwayat Chat List Table -->
    <div class="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
      
      <div class="p-5 border-b border-slate-100 flex items-center justify-between">
        <div>
          <h3 class="text-sm font-black text-slate-900">
            <?= !empty($selectedStudent) ? 'Semua Riwayat Pertanyaan: ' . esc($selectedStudent['nama']) : 'Riwayat Pertanyaan Siswa' ?>
          </h3>
          <p class="text-[11px] text-slate-400">
            <?= !empty($selectedStudent) ? 'Menampilkan seluruh percakapan belajar mandiri siswa ini dengan Gemini AI' : 'Daftar interaksi siswa dengan Gemini AI berpendekatan Pembelajaran Terpadu' ?>
          </p>
        </div>
        <span class="text-xs font-extrabold px-3 py-1 bg-slate-100 text-slate-700 rounded-full">
          <?= count($chatList) ?> Percakapan Ditampilkan
        </span>
      </div>

      <?php if (!empty($chatList)): ?>
        <div class="divide-y divide-slate-100">
          <?php foreach ($chatList as $index => $item): ?>
            <div class="p-5 hover:bg-slate-50/70 transition">
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2.5">
                <div class="flex items-center gap-2.5">
                  <div class="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-black text-xs flex items-center justify-center">
                    <?= strtoupper(substr($item['siswa_nama'], 0, 1)) ?>
                  </div>
                  <div>
                    <h4 class="text-xs font-black text-slate-900"><?= esc($item['siswa_nama']) ?></h4>
                    <p class="text-[10px] text-slate-400">
                      Kelas: <span class="font-bold text-slate-600"><?= esc($item['kelas'] ?? '-') ?></span> • NIS: <?= esc($item['nis'] ?? '-') ?>
                    </p>
                  </div>
                </div>

                <div class="flex items-center gap-2">
                  <span class="px-2.5 py-0.5 rounded-md text-[10px] font-extrabold bg-teal-50 text-teal-700 border border-teal-200">
                    <i class="fa-solid fa-book-open text-[9px] mr-1"></i><?= esc($item['mapel'] ?: ($mapel ?: 'Umum')) ?>
                  </span>
                  <span class="text-[11px] text-slate-400">
                    <i class="fa-regular fa-clock mr-1"></i><?= date('d M Y, H:i', strtotime($item['created_at'])) ?> WIB
                  </span>
                </div>
              </div>

              <!-- Isi Pertanyaan Siswa -->
              <div class="bg-indigo-50/40 border border-indigo-100/80 rounded-2xl p-3.5 mb-2.5">
                <div class="flex items-center gap-1.5 text-[11px] font-extrabold text-indigo-800 mb-1">
                  <i class="fa-solid fa-circle-question text-indigo-600"></i>
                  <span>Pertanyaan Siswa:</span>
                </div>
                <p class="text-xs text-slate-800 font-semibold leading-relaxed">
                  "<?= esc($item['prompt']) ?>"
                </p>
              </div>

              <!-- Cuplikan Jawaban Gemini AI -->
              <div class="bg-slate-50 border border-slate-200/70 rounded-2xl p-3.5">
                <div class="flex items-center justify-between mb-1.5">
                  <div class="flex items-center gap-1.5 text-[11px] font-extrabold text-teal-700">
                    <i class="fa-solid fa-sparkles text-teal-600"></i>
                    <span>Bimbingan Gemini AI (Langkah demi Langkah):</span>
                  </div>
                  <button type="button" onclick="toggleDetail('chat-<?= $index ?>')" class="text-[11px] font-bold text-indigo-600 hover:text-indigo-800">
                    <span id="btn-text-chat-<?= $index ?>">Lihat Lengkap</span> <i class="fa-solid fa-chevron-down text-[9px] ml-0.5"></i>
                  </button>
                </div>
                
                <!-- Singkat -->
                <p id="short-chat-<?= $index ?>" class="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                  <?= esc(strip_tags($item['response'])) ?>
                </p>

                <!-- Lengkap (Hidden by default) -->
                <div id="full-chat-<?= $index ?>" class="hidden text-xs text-slate-700 leading-relaxed whitespace-pre-wrap mt-2 pt-2 border-t border-slate-200">
                  <?= esc($item['response']) ?>
                </div>
              </div>

            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="p-12 text-center">
          <div class="w-14 h-14 mx-auto rounded-3xl bg-slate-100 text-slate-400 flex items-center justify-center text-xl mb-3">
            <i class="fa-regular fa-comments"></i>
          </div>
          <h4 class="text-sm font-bold text-slate-700">Belum Ada Riwayat Obrolan</h4>
          <p class="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            <?= !empty($selectedStudent) ? 'Siswa ini belum pernah menanyakan materi dengan Gemini AI.' : 'Belum ada siswa yang menanyakan materi atau sesuai filter pencarian Anda.' ?>
          </p>
        </div>
      <?php endif; ?>

    </div>

  </main>

  <script>
    function toggleDetail(id) {
      const full = document.getElementById('full-' + id);
      const short = document.getElementById('short-' + id);
      const btnText = document.getElementById('btn-text-' + id);

      if (full.classList.contains('hidden')) {
        full.classList.remove('hidden');
        short.classList.add('hidden');
        btnText.innerText = 'Sembunyikan';
      } else {
        full.classList.add('hidden');
        short.classList.remove('hidden');
        btnText.innerText = 'Lihat Lengkap';
      }
    }
  </script>
</body>
</html>
